import { useState, useEffect } from 'react';
import Card from './Card';
import PropTypes from 'prop-types';

const Body = ({ updateScore, resetScore }) => {
  const [characters, setCharacters] = useState([]);
  const [clickedCharacters, setClickedCharacters] = useState([]);

  useEffect(() => {
    const fetchCharacters = async () => {
      const cloudName = 'your_cloud_name'; // Replace with your Cloud name
      const apiKey = 'your_api_key'; // Replace with your API key
      const apiSecret = 'your_api_secret'; // Replace with your API secret

      const auth = btoa(`${apiKey}:${apiSecret}`); // Base64 encode API key and secret for authentication

      try {
        const response = await fetch(`https://api.cloudinary.com/v1_1/${cloudName}/resources/image/folder/memory-game`, {
          headers: {
            'Authorization': `Basic ${auth}`  // Pass the Basic auth header
          }
        });
        
        const data = await response.json();
        
        // Assuming the images are in the 'resources' array
        const fetchedCharacters = data.resources.map((image) => ({
          name: image.context?.custom?.title || 'Unnamed Character', // Use title from metadata or default to unnamed
          imageUrl: image.secure_url,  // URL for the image
          public_id: image.public_id   // Unique ID for tracking
        }));

        setCharacters(fetchedCharacters);
      } catch (error) {
        console.error('Error fetching characters:', error);
      }
    };

    fetchCharacters();
  }, []);

  const shuffleCharacters = () => {
    setCharacters((prevCharacters) => {
      const shuffled = [...prevCharacters].sort(() => Math.random() - 0.5);
      return shuffled;
    });
  };

  const handleCardClick = (character) => {
    if (clickedCharacters.includes(character.public_id)) {
      alert('Game over! You clicked the same card twice.');
      resetScore();
      setClickedCharacters([]);
    } else {
      setClickedCharacters([...clickedCharacters, character.public_id]);
      updateScore(clickedCharacters.length + 1);
      shuffleCharacters();
    }
  };

  return (
    <div className="body">
      <div className="card-container">
        {characters.map((character) => (
          <Card
            key={character.public_id}
            character={{
              name: character.name,
              imageUrl: character.imageUrl,
            }}
            onClick={() => handleCardClick(character)}
          />
        ))}
      </div>
    </div>
  );
};

Body.propTypes = {
  updateScore: PropTypes.func.isRequired,
  resetScore: PropTypes.func.isRequired,
};

export default Body;

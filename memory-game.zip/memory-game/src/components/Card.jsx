import PropTypes from 'prop-types';

const Card = ({ character, onClick }) => {
  return (
    <div className="card" onClick={onClick}>
      <img src={character.imageUrl} alt={character.name} />
      <p>{character.name}</p>
    </div>
  );
};

Card.propTypes = {
  character: PropTypes.shape({
    name: PropTypes.string.isRequired,
    imageUrl: PropTypes.string.isRequired,
  }).isRequired,
  onClick: PropTypes.func.isRequired,
};

export default Card;
